<?php include "templates/header.php"; ?>

<ul>
	<li><a href="contribute.php"><strong>contribute</strong></a> -go for contribution </li>
	<li><a href="read.php"><strong>Read</strong></a> - find a Employee</li>
	<li><a href="update.php"><strong>Update</strong></a> - edit for Employee</li>
	<li><a href="delete.php"><strong>Delete</strong></a> - delete a Employee</li>
	<li><a href="valuable_Emp.html"><strong>Most valuable contributer Of the year</strong></a> - Find that contributer</li>
</ul>

<?php include "templates/footer.php"; ?>